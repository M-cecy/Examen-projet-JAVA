package model;
import org.json.simple.JSONObject;

import java.time.LocalDate;

public class Reservation {

        private long id;
        private LocalDate date;
        private boolean etat;
        private int duree;
        private  int clientNci;
        private String localRef;
        private Personne personne;

        public Reservation() {
        }

        public Reservation(long id, LocalDate date, boolean etat, int duree,int clientNci, String localRef) {
            this.id = id;
            this.date = date;
            this.etat = etat;
            this.duree = duree;
            this.clientNci=clientNci;
            this.localRef=localRef;
        }


        public Personne getPersonne() {
            return personne;
        }

        public JSONObject setPersonne(Personne personne, JSONObject local) {
            this.personne = personne;
            return local;
        }

    public long getId() {
            return this.id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public LocalDate getDate() {
            return this.date;
        }

        public void setDate(LocalDate date) {
            this.date = date;
        }

        public boolean isEtat() {
            return this.etat;
        }

        public void setEtat(boolean etat) {
            this.etat = etat;
        }

        public int getDuree() {
            return this.duree;
        }

        public void setDuree(int duree) {
            this.duree = duree;
        }

        public int getClientNci() {
            return clientNci;
        }

        public void setClientNci(int clientNci) {
            this.clientNci = clientNci;
        }

        public String getLocalRef() {
            return localRef;
        }

        public void setLocalRef(String localRef) {
        this.localRef = localRef;
    }

        public JSONObject setPersonneExist(JSONObject cl, JSONObject l) {
            return cl;
        }
}
