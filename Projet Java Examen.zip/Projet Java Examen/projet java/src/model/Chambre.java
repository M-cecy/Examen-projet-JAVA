package model;

import java.util.Scanner;

public class Chambre extends Local {
    private int dimension;

    public Chambre() {
    }

    public Chambre(String local, int prix, int taux_loc, int type, int dim) {
        super(local, prix, taux_loc, type);
        this.dimension = dim;
    }
    public Chambre(int prix, int taux_loc, int dim) {
        super( prix, taux_loc);
        this.dimension = dim;
    }
    public int getDimension() {
        return dimension;
    }

    public void setDimension(int dimension) {
        this.dimension = dimension;
    }

    public int cout(){
        return prix + tauxLoc * prix;
    }

    @Override
    public Local add(){

        Scanner sc = new Scanner(System.in);

        do {
            do {
                System.out.print("Reference du local: ");
                this.ref = sc.nextLine();
            } while (this.ref.length() < 3);
        } while (this.ref.length() > 4);

        do {
            System.out.print("Localisation du local: ");
            this.localisation = sc.nextLine();
        } while (this.localisation.length() < 2);

        do {
            do {
                System.out.print("taux de location: ");
                this.tauxLoc = sc.nextInt();
            } while (this.tauxLoc <= 0);
        } while (this.tauxLoc > 100);

        do {
            System.out.print("dimension: ");
            this.dimension = sc.nextInt();
        } while (this.dimension <= 0);

        do {
            System.out.println("Le prix du local (Chambre): ");
            this.prix = sc.nextInt();
        } while (this.prix < 40000);

        sc.close();

        return this;
    }

}
