package model;

import service.Service;

import java.util.ArrayList;
import java.util.Scanner;

public class Appartement extends Local {
    private int nb_pieces;
    private ArrayList<Local> chambres= new ArrayList<>();
    private final Service service = new Service();
    public Appartement() { }



    public Appartement(String ref, String local, int prix, int taux_loc, int type,  int nb_pieces) {
        super(local, prix, taux_loc, type);
        this.nb_pieces = nb_pieces;
    }


    public int getNb_pieces() {
        return nb_pieces;
    }

    public void setNb_pieces(int nb_pieces) {
        this.nb_pieces = nb_pieces;
    }
    public int cout(){
        return prix + tauxLoc * prix;
    }

    public ArrayList<Local> getChambres() {
        return chambres;
    }

    public void setChambres(ArrayList<Local> chambres) {
        this.chambres = chambres;
    }

    @Override
    public Local add() {
        Scanner sc = new Scanner(System.in);

        try {
            do {
                do {
                    System.out.print("Reference du local: ");
                    this.ref = sc.nextLine();
                } while (this.ref.length() < 3);
            } while (this.ref.length() > 4);

            do {
                System.out.print("Localisation du local: ");
                this.localisation = sc.nextLine();
            } while (this.localisation.length() < 2);

            do {
                do {
                    System.out.print("taux de location: ");
                    this.tauxLoc = sc.nextInt();
                } while (this.tauxLoc <= 0);
            } while (this.tauxLoc > 100);

            do {
                System.out.print("\nNombre de pieces: ");
                this.nb_pieces = sc.nextInt();
            } while (this.nb_pieces < 3);

            do {
                System.out.println("Le prix du local (Appartement): ");
                this.prix = sc.nextInt();
            } while (this.prix < 100000);

       ;
            service.writetoGson(this,"src/fichiersJson/appartement.json");

            sc.close();

        } catch (Exception var3) {
            var3.printStackTrace();
        }

        return this;
    }
}

