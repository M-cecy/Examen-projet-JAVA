package model;

public class Personne {

    private int nci;
    private String nomComplet;
    private String tel;
    private String adresse;
    private String email;
    private String role;

    public Personne(){

    }
    public Personne(int nci, String nom, int tel, String adresse, String email) {
        this.nci = this.nci;
        this.nomComplet = nomComplet;
        this.tel = this.tel;
        this.adresse = this.adresse;
        this.email = this.email;
        this.role = role;
    }

    public int getNci() {
        return this.nci;
    }

    public void setNci(int nci) {
        this.nci = nci;
    }

    public String getNomComplet() {
        return this.nomComplet;
    }

    public void setNomComplet(String nomComplet) {
        this.nomComplet = nomComplet;
    }

    public String getTel() {
        return this.tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAdresse() {
        return this.adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String afficher() {
        return "nci : " + getNci() +
                "Nom Complet : " + getNomComplet() +
                "Tel : " + getTel() +
                "Adresse : " + getAdresse() +
                "Email : " + getEmail() +
                "Role : " + getRole();
    }


}