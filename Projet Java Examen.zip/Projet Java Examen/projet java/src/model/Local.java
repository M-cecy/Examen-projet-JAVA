package model;

public abstract class Local {
    private static int nombreLocal;
    protected String ref;
    protected String localisation;
    protected int prix;
    protected int tauxLoc;
    protected int type;

    public Local() {
    }

    public Local(String localisation, int prix, int tauxLoc, int type) {
        //this.ref = generateRef();
        this.localisation = localisation;
        this.prix = prix;
        this.tauxLoc = tauxLoc;
        this.type = type;
    }
    public Local(int prix, int type) {
        //this.ref = generateRef();
        this.prix = prix;
        this.type = type;
    }


    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public int getTauxLoc() {
        return tauxLoc;
    }

    public void setTauxLoc(int tauxLoc) {
        this.tauxLoc = tauxLoc;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public abstract Local add();

    public static enum Type {
        APPARTEMENT, CHAMBRE;

        private Type() {
        }
    }

    /*private String generateRef()
    {
        String nombreZero = "";
        String nombreDeLocalString = String.valueOf(++nombreLocal);
        for(int i=1; i<=(FORMAT - nombreDeLocalString.length()); i++)
        {
            nombreZero += "0";
        }
        return "Ref" + nombreZero + nombreDeLocalString ;
    }*/
}

