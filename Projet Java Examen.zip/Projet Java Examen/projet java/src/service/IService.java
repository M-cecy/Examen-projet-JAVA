package service;

import model.*;
import org.json.simple.*;

public interface IService {

/*
    public Boolean ajouterLocal(Local local);
    public Local afficherLocal(String ref);
    public Boolean ajouterReservation(Reservation reservation);
    public Boolean annulerReservation(String ref);
    public ArrayList<Chambre> listerChambre();

    public default ArrayList<Appartement> listerAppartement() {
        return null;
    }
    public ArrayList<Local> listerLocauxDisponible();
    public void createLocal(Local local);
    public ArrayList<Local> chercherLocal(String type);
    public void createPersonne(Personne personne);
    public ArrayList<Personne> chercherPersonne(int nci);
    public File createReservation(Reservation reservation);
    public ArrayList<Reservation> chercherReservation(int id);
    public void afficherDetail();
    public ArrayList<Local> searchLocalByRef(String ref);
    public ArrayList<Local> searchLocalByRes(int nci);
    public ArrayList<Reservation> searchReservationByPer(int nci);
*/


    public default JSONObject createClient(Personne personne) {
        return null;
    }

    public JSONObject createReservation(Reservation reservation);
    public JSONArray searchClient(int nci);
    public JSONArray searchLocal(String type);
    public JSONArray searchReservation(int id);
    public void lister(String file);
    public void ListerLocalReservationByClient(int nci);
    public void ListerLocalDispo();
    public void Detail(JSONArray local);







}
