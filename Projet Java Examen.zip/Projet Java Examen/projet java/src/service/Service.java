package service;

import jsonFile.jsonFile;
import model.Local;
import model.Personne;
import model.Reservation;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class Service implements IService
{
    private final JSONArray listeReservation= new  JSONArray();
    private final JSONArray listeClient= new  JSONArray();
    private  JSONArray listeLocal = new  JSONArray();
    //copier coller la partie qui contient jsonFile et Parser
    private jsonFile js = new jsonFile();
    private parser parse = new parser();

    @Override
    public JSONObject createClient(Personne personne)
    {
        JSONObject p = new JSONObject();
        p.put("nci", personne.getNci());
        p.put("nomComplet", personne.getNomComplet());
        p.put("tel", personne.getTel());
        p.put("adresse", personne.getAdresse());
        p.put("email", personne.getEmail());
        return p;
    }
    @Override
    public JSONObject createReservation(Reservation reservation)
    {
        JSONObject reser = new JSONObject();
        reser.put("id", reservation.getId());
        reser.put("duree", reservation.getDuree());
        reser.put("etat", reservation.isEtat());
        reser.put("date", reservation.getDate());
        return reser;
    }

    @Override
    public JSONArray searchClient(int nci)
    {
        JSONArray dataClient = new JSONArray();
        JSONArray lList = js.readFile("Clients.json", listeClient);
        lList.forEach( emp -> parse.parseObjectCl( (JSONObject) emp , dataClient, nci));
        return dataClient;
    }

    @Override
    public JSONArray searchLocal(String type)
    {

        JSONArray dataLocal = new JSONArray();
        JSONArray lList = js.readFile("Locaux.json", listeLocal);
        lList.forEach( emp -> parse.parseObject( (JSONObject) emp , dataLocal, type ,"type"));
        return dataLocal;
    }

    @Override
    public JSONArray searchReservation(int id) {
        JSONArray dataReservation = new JSONArray();
        JSONArray lList = js.readFile("Reservation.json", listeReservation);
        lList.forEach( emp -> parse.parseObjectRsL((JSONObject) emp , dataReservation , id,"id"));
        return dataReservation;
    }
    @Override
    public void lister(String file)
    {
        JSONArray lList = js.readFile("Reservation.json", listeLocal);
        lList.forEach( emp -> parse.parseObjectAll( (JSONObject) emp) );

    }
    @Override
    public void ListerLocalReservationByClient(int nci) {
        JSONArray lList = js.readFile("Reservation.json", listeReservation);
        lList.forEach( emp -> parse.parseObjectRsClShow( (JSONObject) emp , nci));

    }
    @Override
    public void ListerLocalDispo() {
        JSONArray lList = js.readFile("local.json", listeLocal);
        lList.forEach( emp -> parse.parseObjectLDispo( (JSONObject) emp) );
    }

    @Override
    public void Detail(JSONArray local)
    {
        local.forEach( emp -> parse.parseObjectInfo( (JSONObject) emp) );
    }

    public void annulerReservation(int idCancel)
    {
        JSONArray obj = searchReservation(idCancel);
        if ( obj != null)
        {
            obj.forEach( emp -> {
                ((String)emp).replace("etat", "false");
            });
        }
    }
    public JSONArray searchLocalByRef(String ref) {
        JSONArray data = new JSONArray();
        JSONArray lList = js.readFile("Local.json", listeLocal);
        lList.forEach( emp -> parse.parseObject( (JSONObject) emp , data, ref,"ref"));
        return data;
    }
    public JSONArray searchLocalByRes(int nci) {
        JSONArray dataReservation = new JSONArray();
        JSONArray lList = js.readFile("Reservation.json", listeReservation);
        lList.forEach( emp -> parse.parseObjectRsL( (JSONObject) emp , dataReservation , nci, "id"));
        return dataReservation;
    }
    public JSONArray searchReservationByclient(int nci) {
        JSONArray dataReservation = new JSONArray();
        JSONArray lList = js.readFile("Reser.json", listeReservation);
        lList.forEach( emp -> parse.parseObjectRsCl( (JSONObject) emp , dataReservation , nci));
        return dataReservation;
    }

    public void writetoGson(Local appartement, String s) {
    }

    public JSONArray readFile(String s, JSONArray json) {
        return json;
    }

    public void saveFile(JSONArray dataR, String s) {
    }


    public static class parser
    {
        private static void parseObject(JSONObject object, JSONArray data , String typeLocal , String key )
         {
             String type = (String) object.get(key);
             if (type.compareToIgnoreCase(typeLocal)==0)
             {
                 data.add(object);
             }
        }
         private static void parseObjectCl(JSONObject object, JSONArray data , int nci )
         {
             String ncI = (String) object.get("nci").toString();
             int cle = Integer.parseInt(ncI);
             if (cle == nci)
             {
                 data.add(object);
             }
        }
        private static void parseObjectRsCl(JSONObject object, JSONArray data , int nci)
            {
                 JSONObject ob = (JSONObject) object.get("client");
                 JSONObject obL = (JSONObject) object.get("local");
                 String nc = (String) ob.get("nci").toString();
                 int cle = Integer.parseInt(nc);
                 if (cle == nci)
                 {
                      Object id =  object.get("id").toString();
                      Object duree =  object.get("duree");
                      Object etat = object.get("etat");
                      Object date =  object.get("date");
                             JSONObject Obt = new JSONObject();
                             Obt.put("id",id);
                             Obt.put("duree",duree);
                             Obt.put("etat",etat);
                             Obt.put("date",date);
                             JSONObject Ob = new JSONObject();
                             Ob.put("reservation", Obt);
                             Ob.put("local",obL);
                             data.add(Ob);
                 }
            }
        private static void parseObjectRsL(JSONObject object, JSONArray data, int nci, String id)
        {
             JSONObject ob = (JSONObject) object.get("client");
             String nc = (String) ob.get("nci").toString();
             int cle = Integer.parseInt(nc);
             if (cle == nci)
             {
                  Object Id =  object.get("id");
                  Object duree =  object.get("duree");
                  Object etat = object.get("etat");
                  Object date =  object.get("date");
                         JSONObject Obt = new JSONObject();
                         Obt.put("id",Id);
                         Obt.put("duree",duree);
                         Obt.put("etat",etat);
                         Obt.put("date",date);
                         JSONObject Ob = new JSONObject();
                         Ob.put("reservation", Obt);
                         Ob.put("client", ob);
                         data.add(Ob);
             }
        }
        private static void parseObjectRsClShow(JSONObject object , int nci)
            {
                 JSONObject ob = (JSONObject) object.get("client");
                 JSONObject obL = (JSONObject) object.get("local");
                 String nc = (String) ob.get("nci").toString();
                 int cle = Integer.parseInt(nc);
                 if (cle == nci)
                 {
                     System.out.println(obL);
                 }
            }
         public static void parseObjectInfo(JSONObject object)
         {
            String ref = (String) object.get("ref");
            String localisation = (String) object.get("localisation");
            Object prix =  object.get("prix");
            Object tauxPoc = object.get("tauxPoc");
            String type = (String) object.get("type");
            System.out.println
            (""
                    + "\n \t ref : " + ref
                    +"\n \t localisation : "+localisation
                    +"\n \t prix : "+prix
                    +"\n \t tauxPoc : "+tauxPoc
                    +"\n \t type : "+type
            );
         }
         public static void parseObjectAll(JSONObject object)
         {
             System.out.println(object);
        }
        public static void parseObjectLDisp(JSONObject object , JSONArray data)
         {
             Object key =  object.get("reservation");
             if (key == null) {
                 System.out.println("Les locaux disponibles "
                         + "\n\n");
                 System.out.println("\t\t"+object);
                 data.add(object);
             }
        }
         public static void parseObjectLDispo(JSONObject object)
         {
              Object key =  object.get("reservation");
             if (key == null) {
                 System.out.println("Les locaux disponibles "
                         + "\n\n");
                 System.out.println("\t\t"+object);
             }
        }
    }
}

