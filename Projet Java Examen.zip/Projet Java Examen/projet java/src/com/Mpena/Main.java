package com.Mpena;

import jsonFile.jsonFile;
import lib.Validator;
import model.Appartement;
import model.Chambre;
import model.Personne;
import model.Reservation;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import service.Service;

import java.util.Scanner;

public class Main {

    private static jsonFile file;
    private static String email;
    private static int tel;
    private static String adresse;
    private static String nomComplet;
    private static Object Personne;
    private static int nci;
    private static Personne personne;
    private static JSONArray js;
    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        Service service = new Service();
        Validator val = new Validator();
        jsonFile file  = new jsonFile();

        //ArrayList<Personne> personnes = service.getArrayListPersonne();

        //int choice = false;
        var ch = new Chambre();
        var app = new Appartement();
        //char response = true;

        int choice;
        do {
            do {
                System.out.println("================== MENU =====================\n");
                System.out.println("1- Ajouter un local");
                System.out.println("2- Lister les locaux reseré par un client");
                System.out.println("3- Voir les details d'un local");
                System.out.println("4- Faire une reservation");
                System.out.println("5- Annuler une reservation");
                System.out.println("6- Lister les locaux disponibles");
                System.out.println("7- Quitter");
                choice = sc.nextInt();
            } while (choice <= 0);
        } while (choice > 8);

        switch (choice) {
            case 1:
                int choice2;
                do {
                    do {
                        System.out.println("------   Type de local  --------");
                        System.out.println("1-  APPARTEMENT                 ");
                        System.out.println("2-  CHAMBRE                     ");
                        choice2 = sc.nextInt();
                    } while (choice2 <= 0);
                } while (choice2 > 2);

                if (choice2 == 1) {
                    var tmp = app.add();
                    service.writetoGson(tmp, "src/fichiersJson/appartement.json");

                } else {
                    var tmp2 = ch.add();
                    service.writetoGson(tmp2, "src/fichiersJson/chambre.json");
                }
            case 2:
                System.out.println(" Lister le local reserver par un client");
                System.out.println("veuillez entrez le nci ");
                int nci = Integer.parseInt(sc.nextLine());
                service.ListerLocalReservationByClient(nci);

            case 3:
                System.out.println("Afficher les details d'un local");
                System.out.println("veuillez entrez la reference du local en format RefCCCC ");
                String ref = sc.nextLine();
                JSONArray data = service.searchLocalByRef(ref);
                service.Detail(data);
            case 4:
                System.out.println(" Lister le local reserver par un client");
                System.out.println("veuillez entrez le nci ");
                nci = Integer.parseInt(sc.nextLine());
                System.out.println("Faire une reservation");
                Personne = new Personne(nci,nomComplet, tel, adresse, email);
                Reservation res = new Reservation();
                System.out.println("Veuillez saisir le nci du client");
                nci  = Integer.parseInt(sc.nextLine());
                System.out.println("Veuillez saisir la reference du local ");
                ref  = sc.nextLine();
                js	=  service.searchClient(nci);
                if (js.isEmpty())
                {
                    System.out.println("Veuillez vous inscrire "+"\n Veuillez saisir votre nci ");
                    nci = Integer.parseInt(sc.nextLine());
                    System.out.println("Veuillez saisir votre nom Complet ");
                    String nom = sc.nextLine();
                    System.out.println("Veuillez saisir votre numéro de téléphone ");
                    int tel = Integer.parseInt(sc.nextLine());
                    System.out.println("Veuillez saisir l'adresse ");
                    String adresse =sc.nextLine();
                    System.out.println("Veuillez saisir votre email ");
                    String email =sc.nextLine();
                    personne = new Personne(nci, nom, tel, adresse, email);
                    js	=  service.searchLocal(ref);
                    if (!js.isEmpty())
                    {
                        JSONObject local = (JSONObject) js.get(0);
                        JSONObject obj = res.setPersonne(personne,local);
                        JSONArray json =  new JSONArray();
                        JSONArray jsonR =  new JSONArray();
                        JSONArray jsonL =  new JSONArray();
                        JSONArray dataR = file.readFile("Reser.json",json);
                        dataR.add(obj);
                        file.saveFile(dataR,"Reser.json");
                        JSONArray jsonArray = service.searchReservationByclient(personne.getNci());
                        JSONObject cli = service.createClient(personne);
                        cli.put("reservation", jsonArray);
                        JSONArray jsonArrayL = service.searchLocalByRes(personne.getNci());
                        local.put("reservation", jsonArrayL);
                        JSONArray donnee = file.readFile("Clients.json", jsonR);
                        donnee.add(cli);
                        file.saveFile(donnee,"Clients.json");
                        JSONArray dataL = file.readFile("Locaux.json", jsonL);
                        dataL.add(local);
                        file.saveFile(dataL,"Locaux.json");
                    }
                    break;
                }else
                {
                    JSONObject cl = (JSONObject) js.get(0);
                    js	=  service.searchLocal(ref);
                    if (!js.isEmpty())
                    {
                        JSONObject l = (JSONObject) js.get(0);
                        JSONObject obj = res.setPersonneExist(cl,l);

                        JSONArray json =  new JSONArray();
                        JSONArray jsonR =  new JSONArray();
                        JSONArray jsonL =  new JSONArray();
                        JSONArray dataR = service.readFile("Reser.json",json);
                        dataR.add(obj);
                        service.saveFile(dataR,"Reser.json");
                        String nc = (String) cl.get("nci").toString();
                        nci= Integer.parseInt(nc);
                        JSONArray jsonArray = service.searchReservationByclient(nci);
                        cl.put("reservation", jsonArray);
                        JSONArray jsonArrayL = service.searchLocalByRes(nci);
                        l.put("reservation", jsonArrayL);
                        JSONArray donnee = file.readFile("Clients.json", jsonR);
                        donnee.add(cl);
                        file.saveFile(donnee,"Clients.json");
                        JSONArray dataL = file.readFile("Locaux.json", jsonL);
                        dataL.add(l);
                        file.saveFile(dataL,"Locaux.json");
                    }
                }
            case 5:
                System.out.println("Annuler la reservation");
                service.lister("Reser.json");
                System.out.println("\n\nVeuillez saisir l' id de la reservation ");
                /*t = sc.nextLine();
                if (Validator.isValidNom(t) || !val.isNumeric(t)) {
                    t =sc.nextLine();
                }
                int id = Integer.parseInt(t);
                service.annulerReservation(id);*/
            case 6:
                System.out.println("Lister les locaux disponibles");
                service.ListerLocalDispo();
            case 7:
                System.out.println("Quitter");
                break;
            default:
                System.out.println("Mauvais choix");
        }

        sc.close();
    }


}
